package com.example.suma;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText number1EditText = findViewById(R.id.number1EditText);
        EditText number2EditText = findViewById(R.id.number2EditText);
        Button addButton = findViewById(R.id.addButton);
        TextView resultTextView = findViewById(R.id.resultTextView);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1 = number1EditText.getText().toString();
                String num2 = number2EditText.getText().toString();

                if (!num1.isEmpty() && !num2.isEmpty()) {
                    try {
                        double number1 = Double.parseDouble(num1);
                        double number2 = Double.parseDouble(num2);
                        double sum = number1 + number2;
                        resultTextView.setText("Result: " + sum);
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                    }
            }else {
                    Toast.makeText(MainActivity.this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
                }
    }
});
    }
}